<?php
$host = "localhost";
$path = "root";
$abir = "";
$dbname = "database";
// Create connection
$con1 = mysqli_connect($host, $path, $abir,$dbname);
?>
